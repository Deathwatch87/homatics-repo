# -*- coding: utf-8 -*-
"""Patch Guard engine.

Pure Python (3.8 compatible), no Kodi imports, so it can be tested outside Kodi.

A *patch* targets one file of one addon and holds one or more *hunks*:

    {"before": [lines], "remove": [lines], "add": [lines], "after": [lines]}

`before`/`after` are context lines that identify WHERE the change goes; `remove` are the
lines the original has there (may be empty for a pure insertion); `add` are our lines.

Rules the engine follows:
  * all-or-nothing per file: if any hunk cannot be placed with certainty, nothing is written
  * a hunk is placed only where its pattern matches exactly ONCE (context is reduced step by
    step if upstream changed the surrounding lines, but never below MIN_PATTERN_LINES)
  * line endings (LF/CRLF, mixed) and a UTF-8 BOM are preserved
  * python files must still compile, XML/JSON must still parse (if they parsed before)
  * the original is backed up, the new file is written to a temp file and swapped in atomically
"""
import difflib
import json
import os
import shutil
import time
import xml.etree.ElementTree as ET

ST_APPLIED = 'applied'
ST_NEEDS = 'needs_apply'
ST_PARTIAL = 'partial'
ST_ANCHOR = 'anchor_missing'
ST_AMBIGUOUS = 'ambiguous'
ST_NOADDON = 'addon_missing'
ST_NOFILE = 'file_missing'

OK_STATUSES = (ST_APPLIED,)
FIXABLE_STATUSES = (ST_NEEDS, ST_PARTIAL)
BLOCKED_STATUSES = (ST_ANCHOR, ST_AMBIGUOUS, ST_NOFILE)

MIN_PATTERN_LINES = 3   # never anchor on fewer lines than this (unless the block itself is that long)


# ----------------------------------------------------------------------------- file helpers

def read_text(path):
    """Return (text, has_bom). Raises on undecodable files."""
    with open(path, 'rb') as fh:
        raw = fh.read()
    bom = raw.startswith(b'\xef\xbb\xbf')
    if bom:
        raw = raw[3:]
    return raw.decode('utf-8'), bom


def parse_lines(text):
    """Split text into (lines without eol, eols). Only \\n and \\r\\n are line breaks."""
    parts = text.split('\n')
    lines, eols = [], []
    for i, part in enumerate(parts):
        last = (i == len(parts) - 1)
        if last:
            if part == '':
                break
            lines.append(part)
            eols.append('')
        elif part.endswith('\r'):
            lines.append(part[:-1])
            eols.append('\r\n')
        else:
            lines.append(part)
            eols.append('\n')
    return lines, eols


def join_lines(lines, eols):
    return ''.join(l + e for l, e in zip(lines, eols))


def _dominant_eol(eols):
    crlf = sum(1 for e in eols if e == '\r\n')
    lf = sum(1 for e in eols if e == '\n')
    return '\r\n' if crlf > lf else '\n'


# ----------------------------------------------------------------------------- hunk location

def _find_sublist(lines, pat):
    """All start indexes where `pat` occurs as a contiguous block of `lines`."""
    n, m = len(lines), len(pat)
    if m == 0 or m > n:
        return []
    first = pat[0]
    hits = []
    for i in range(n - m + 1):
        if lines[i] == first and lines[i:i + m] == pat:
            hits.append(i)
    return hits


def hunk_state(lines, hunk):
    """State of one hunk against current file lines.

    -> ('applied'|'needs_apply'|'missing'|'ambiguous', index, k)

    Two shapes are looked for at the SAME context size, from the full stored context downwards:
      old shape = before + remove + after   (the upstream original: fix still to apply)
      new shape = before + add    + after   (our fix is already in)
    The first context size at which either shape matches decides. Deciding both at once is
    essential: a reduced-context search for "already applied" could otherwise match a
    *neighbouring* fix that inserts identical text and wrongly skip this one.
    """
    before, remove, add, after = hunk['before'], hunk['remove'], hunk['add'], hunk['after']
    kmax = max(len(before), len(after))
    # An OLDER version of our own fix may already be in the file ("legacy" add blocks listed in the manifest).
    # Recognised at full context only; applying then swaps that block for the new one.
    for old_add in hunk.get('legacy_adds', []):
        leg_pat = before + old_add + after
        if len(leg_pat) >= MIN_PATTERN_LINES and leg_pat != before + add + after:
            leg_hits = _find_sublist(lines, leg_pat)
            if len(leg_hits) == 1 and not _find_sublist(lines, before + add + after):
                return 'needs_apply', leg_hits[0] + len(before), kmax
    for k in range(kmax, -1, -1):
        b = before[-k:] if k and before else []
        a = after[:k] if k and after else []
        old_pat = b + remove + a
        new_pat = b + add + a
        old_ok = bool(old_pat) and (len(old_pat) >= MIN_PATTERN_LINES or len(remove) >= MIN_PATTERN_LINES)
        new_ok = bool(new_pat) and (len(new_pat) >= MIN_PATTERN_LINES or len(add) >= MIN_PATTERN_LINES)
        old_hits = _find_sublist(lines, old_pat) if old_ok else []
        new_hits = _find_sublist(lines, new_pat) if new_ok and new_pat != old_pat else []
        if not old_hits and not new_hits:
            continue
        if len(new_hits) == 1 and not old_hits:
            return 'applied', new_hits[0] + len(b), k
        if len(old_hits) == 1 and not new_hits:
            return 'needs_apply', old_hits[0] + len(b), k
        return 'ambiguous', -1, k
    return 'missing', -1, -1


# ----------------------------------------------------------------------------- validation

def validate_text(path, new_text, old_text):
    """Return (ok, message). Only fails if the new file is broken but the old one was fine."""
    low = path.lower()
    if low.endswith('.py'):
        try:
            compile(new_text, path, 'exec', dont_inherit=True)
        except (SyntaxError, ValueError) as exc:
            return False, 'python syntax check failed: %s' % exc
        return True, 'python ok'
    if low.endswith('.xml'):
        try:
            ET.fromstring(old_text.encode('utf-8'))
        except Exception:
            return True, 'xml not validated (original was not strict XML)'
        try:
            ET.fromstring(new_text.encode('utf-8'))
        except Exception as exc:
            return False, 'xml parse failed: %s' % exc
        return True, 'xml ok'
    if low.endswith('.json'):
        try:
            json.loads(new_text)
        except Exception as exc:
            return False, 'json parse failed: %s' % exc
        return True, 'json ok'
    return True, 'no validator for this file type'


# ----------------------------------------------------------------------------- manifest

def load_manifest(path):
    with open(path, 'r', encoding='utf-8') as fh:
        data = json.load(fh)
    if not isinstance(data, dict) or 'patches' not in data:
        raise ValueError('manifest has no "patches" list')
    return data


def addon_version(addons_root, addon_id):
    xml_path = os.path.join(addons_root, addon_id, 'addon.xml')
    try:
        root = ET.parse(xml_path).getroot()
        return root.get('version') or '?'
    except Exception:
        return None


def patch_path(addons_root, patch):
    return os.path.join(addons_root, patch['addon'], *patch['file'].split('/'))


# ----------------------------------------------------------------------------- checking

def check_patch(patch, addons_root):
    """Evaluate one patch without touching anything."""
    res = {
        'id': patch['id'], 'group': patch.get('group', ''), 'addon': patch['addon'],
        'file': patch['file'], 'restart': patch.get('restart', 'none'),
        'description': patch.get('description', ''),
        'version': addon_version(addons_root, patch['addon']),
        'tested_on': patch.get('tested_on', ''),
        'hunks': [], 'status': ST_NOADDON, 'detail': '', 'fuzzy': False,
    }
    if res['version'] is None:
        res['detail'] = 'addon %s is not installed' % patch['addon']
        return res
    path = patch_path(addons_root, patch)
    if not os.path.isfile(path):
        res['status'] = ST_NOFILE
        res['detail'] = 'file not found: %s' % patch['file']
        return res
    try:
        text, _bom = read_text(path)
    except Exception as exc:  # undecodable / unreadable
        res['status'] = ST_NOFILE
        res['detail'] = 'cannot read file: %s' % exc
        return res
    lines, _eols = parse_lines(text)
    states = []
    for i, hunk in enumerate(patch['hunks']):
        st, idx, k = hunk_state(lines, hunk)
        full = max(len(hunk['before']), len(hunk['after']))
        res['hunks'].append({'n': i + 1, 'state': st, 'index': idx, 'context': k, 'full_context': full})
        states.append(st)
        if st in ('applied', 'needs_apply') and 0 <= k < full:
            res['fuzzy'] = True
    if any(s == 'ambiguous' for s in states):
        res['status'] = ST_AMBIGUOUS
        res['detail'] = 'hunk(s) %s match more than one place' % [i + 1 for i, s in enumerate(states) if s == 'ambiguous']
    elif any(s == 'missing' for s in states):
        res['status'] = ST_ANCHOR
        res['detail'] = 'could not find where hunk(s) %s belong (upstream code changed?)' % [i + 1 for i, s in enumerate(states) if s == 'missing']
    elif all(s == 'applied' for s in states):
        res['status'] = ST_APPLIED
    elif all(s == 'needs_apply' for s in states):
        res['status'] = ST_NEEDS
    else:
        res['status'] = ST_PARTIAL
    return res


def check_all(manifest, addons_root):
    return [check_patch(p, addons_root) for p in manifest['patches']]


def file_age_seconds(addons_root, patch):
    try:
        return time.time() - os.path.getmtime(patch_path(addons_root, patch))
    except OSError:
        return 0.0


# ----------------------------------------------------------------------------- applying

def apply_patch(patch, addons_root, backup_dir, min_age=0.0):
    """Apply every missing hunk of one patch, all-or-nothing. Returns a result dict."""
    check = check_patch(patch, addons_root)
    out = {'id': patch['id'], 'addon': patch['addon'], 'file': patch['file'],
           'restart': patch.get('restart', 'none'), 'changed': False, 'ok': False,
           'message': '', 'fuzzy': check['fuzzy']}
    if check['status'] == ST_APPLIED:
        out['ok'] = True
        out['message'] = 'already applied'
        return out
    if check['status'] not in FIXABLE_STATUSES:
        out['message'] = 'not applied: %s - %s' % (check['status'], check['detail'])
        return out
    if min_age and file_age_seconds(addons_root, patch) < min_age:
        out['message'] = 'file changed %.0fs ago - waiting for it to settle' % file_age_seconds(addons_root, patch)
        out['waiting'] = True
        return out

    path = patch_path(addons_root, patch)
    text, bom = read_text(path)
    lines, eols = parse_lines(text)
    base_eol = _dominant_eol(eols)

    for hunk in patch['hunks']:
        st, idx, _k = hunk_state(lines, hunk)
        if st == 'applied':
            continue
        if st != 'needs_apply':          # cannot happen after the check above, but never guess
            out['message'] = 'hunk could not be placed (%s) - nothing written' % st
            return out
        remove, add = hunk['remove'], hunk['add']
        for old_add in hunk.get('legacy_adds', []):      # swap an older version of this fix instead of the original code
            if old_add and lines[idx:idx + len(old_add)] == list(old_add) and lines[idx:idx + len(remove)] != list(remove):
                remove = list(old_add)
                break
        if idx > 0 and eols[idx - 1] == '':
            eols[idx - 1] = base_eol      # previous last line had no newline; it must get one now
        eol = eols[idx - 1] if idx > 0 else (eols[idx] if idx < len(eols) and eols[idx] else base_eol)
        lines[idx:idx + len(remove)] = list(add)
        eols[idx:idx + len(remove)] = [eol] * len(add)

    # a final line without newline stays without; otherwise nothing special needed
    new_text = join_lines(lines, eols)
    ok, msg = validate_text(path, new_text, text)
    if not ok:
        out['message'] = 'refused: %s' % msg
        return out

    # backup, then atomic swap
    rel = os.path.join(patch['addon'], *patch['file'].split('/'))
    backup_path = os.path.join(backup_dir, rel)
    os.makedirs(os.path.dirname(backup_path), exist_ok=True)
    shutil.copy2(path, backup_path)
    tmp = path + '.pgtmp'
    data = new_text.encode('utf-8')
    if bom:
        data = b'\xef\xbb\xbf' + data
    with open(tmp, 'wb') as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    out['changed'] = True
    out['ok'] = True
    out['message'] = 'applied (%s)' % msg
    return out


def new_backup_dir(backup_root):
    stamp = time.strftime('%Y%m%d-%H%M%S')
    path = os.path.join(backup_root, stamp)
    n = 1
    while os.path.exists(path):
        n += 1
        path = os.path.join(backup_root, '%s-%d' % (stamp, n))
    return path


def apply_all(manifest, addons_root, backup_root, only_ids=None, min_age=0.0):
    """Apply all fixable patches (or just `only_ids`). Returns list of result dicts."""
    backup_dir = new_backup_dir(backup_root)
    results = []
    for patch in manifest['patches']:
        if only_ids is not None and patch['id'] not in only_ids:
            continue
        try:
            results.append(apply_patch(patch, addons_root, backup_dir, min_age=min_age))
        except Exception as exc:  # never let one bad patch stop the rest
            results.append({'id': patch['id'], 'addon': patch['addon'], 'file': patch['file'],
                            'restart': patch.get('restart', 'none'), 'changed': False, 'ok': False,
                            'message': 'error: %s' % exc})
    if not any(r.get('changed') for r in results):
        if os.path.isdir(backup_dir):
            shutil.rmtree(backup_dir, ignore_errors=True)
        backup_dir = None
    return results, backup_dir


# ----------------------------------------------------------------------------- rollback

def list_backups(backup_root):
    if not os.path.isdir(backup_root):
        return []
    return sorted(d for d in os.listdir(backup_root) if os.path.isdir(os.path.join(backup_root, d)))


def prune_backups(backup_root, keep=20):
    """Delete the oldest backup folders, keeping the newest `keep`. Returns how many were removed."""
    names = list_backups(backup_root)
    removed = 0
    for name in names[:max(0, len(names) - keep)]:
        shutil.rmtree(os.path.join(backup_root, name), ignore_errors=True)
        removed += 1
    return removed


def rollback(backup_dir, addons_root):
    """Restore every file saved in `backup_dir`. Returns list of restored relative paths."""
    restored = []
    for dirpath, _dirs, files in os.walk(backup_dir):
        for name in files:
            src = os.path.join(dirpath, name)
            rel = os.path.relpath(src, backup_dir)
            dst = os.path.join(addons_root, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            tmp = dst + '.pgtmp'
            shutil.copy2(src, tmp)
            os.replace(tmp, dst)
            restored.append(rel)
    return restored


# ----------------------------------------------------------------------------- diagnostics

def attention_snapshot(patch, addons_root, window=14):
    """Text describing why a patch could not be placed, for a human/the next session."""
    path = patch_path(addons_root, patch)
    out = ['Patch: %s  (%s :: %s)' % (patch['id'], patch['addon'], patch['file']),
           'Installed version: %s   Tested on: %s' % (addon_version(addons_root, patch['addon']), patch.get('tested_on', '?')), '']
    try:
        text, _bom = read_text(path)
    except Exception as exc:
        return '\n'.join(out + ['cannot read file: %s' % exc])
    lines, _eols = parse_lines(text)
    for n, hunk in enumerate(patch['hunks'], 1):
        st, _idx, _k = hunk_state(lines, hunk)
        if st in ('applied', 'needs_apply'):
            continue
        out.append('=== hunk %d: %s ===' % (n, st))
        out.append('Expected context before:')
        out += ['   | ' + l for l in hunk['before'][-3:]]
        out.append('Expected original lines:')
        out += ['   - ' + l for l in hunk['remove']]
        out.append('Our lines to add:')
        out += ['   + ' + l for l in hunk['add']]
        if hunk['remove']:
            probe = hunk['remove'][0].strip()
        elif hunk['before']:
            probe = hunk['before'][-1].strip()
        else:
            probe = (hunk['after'] or [''])[0].strip()
        best_i, best_r = -1, 0.0
        for i, line in enumerate(lines):
            r = difflib.SequenceMatcher(None, probe, line.strip()).ratio() if probe else 0.0
            if r > best_r:
                best_i, best_r = i, r
        if best_i >= 0:
            lo, hi = max(0, best_i - window), min(len(lines), best_i + window)
            out.append('Closest place in the new file (line %d, similarity %.0f%%):' % (best_i + 1, best_r * 100))
            out += ['   %5d  %s' % (i + 1, lines[i]) for i in range(lo, hi)]
        out.append('')
    return '\n'.join(out)


def summarize(results):
    counts = {}
    for r in results:
        counts[r['status']] = counts.get(r['status'], 0) + 1
    return counts
