# -*- coding: utf-8 -*-
"""Kodi glue shared by the background service and the menu screen."""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib import engine

ADDON_ID = 'service.patchguard'
SETTLE_SECONDS = 90            # a file must be this old before the service touches it
MAX_EVENT_LINES = 200


def log(msg, level=None):
    xbmc.log('[PatchGuard] %s' % msg, xbmc.LOGINFO if level is None else level)


def paths():
    addons_root = xbmcvfs.translatePath('special://home/addons')
    data = xbmcvfs.translatePath('special://profile/addon_data/%s' % ADDON_ID)
    return {
        'addons': addons_root,
        'data': data,
        'manifest': os.path.join(data, 'patches.json'),
        'backups': os.path.join(data, 'backups'),
        'report': os.path.join(data, 'report.json'),
        'attention': os.path.join(data, 'attention'),
        'events': os.path.join(data, 'events.log'),
        'heartbeat': os.path.join(data, 'heartbeat.json'),
        'versions': os.path.join(data, 'versions.json'),
    }


def ensure_dirs():
    p = paths()
    for key in ('data', 'backups', 'attention'):
        os.makedirs(p[key], exist_ok=True)
    return p


def setting_bool(name, default=False):
    try:
        val = xbmcaddon.Addon(ADDON_ID).getSetting(name)
    except Exception:
        return default
    if val == '':
        return default
    return val.lower() == 'true'


def setting_int(name, default):
    try:
        return int(xbmcaddon.Addon(ADDON_ID).getSetting(name) or default)
    except (TypeError, ValueError):
        return default


def load_manifest():
    p = paths()
    # A fix list shipped inside the addon (used on devices that keep no list of their own) seeds the data folder,
    # and replaces the copy there when the shipped one is newer (so a Patch Guard update can bring new fixes).
    bundled = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'patches.json')
    if os.path.isfile(bundled):
        try:
            with open(bundled, 'rb') as src:
                new_bytes = src.read()
            newer = not os.path.isfile(p['manifest'])
            if not newer:
                try:
                    with open(p['manifest'], 'r', encoding='utf-8') as fh:
                        have = json.load(fh).get('generated', '')
                    newer = str(json.loads(new_bytes.decode('utf-8')).get('generated', '')) > str(have)
                except Exception:
                    newer = True          # unreadable list on disk: take the shipped one
            if newer:
                ensure_dirs()
                tmp = p['manifest'] + '.tmp'
                with open(tmp, 'wb') as dst:
                    dst.write(new_bytes)
                os.replace(tmp, p['manifest'])
                event('installed the bundled fix list')
        except Exception as exc:
            return None, 'Could not install the bundled fix list: %s' % exc
    if not os.path.isfile(p['manifest']):
        return None, 'No fix list found at %s' % p['manifest']
    try:
        return engine.load_manifest(p['manifest']), ''
    except Exception as exc:
        return None, 'Fix list could not be read: %s' % exc


def event(text):
    """Append a line to events.log (kept short)."""
    p = ensure_dirs()
    line = '%s  %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), text)
    log(text)
    try:
        lines = []
        if os.path.isfile(p['events']):
            with open(p['events'], 'r', encoding='utf-8') as fh:
                lines = fh.read().splitlines()
        lines.append(line)
        with open(p['events'], 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(lines[-MAX_EVENT_LINES:]) + '\n')
    except Exception:
        pass


def heartbeat(state):
    """Written by the background service after every cycle so the menu can show it is alive."""
    p = ensure_dirs()
    try:
        with open(p['heartbeat'], 'w', encoding='utf-8') as fh:
            json.dump({'time': time.time(), 'text': time.strftime('%Y-%m-%d %H:%M:%S'), 'state': state,
                       'interval': max(2, setting_int('check_interval', 10)),
                       'auto_apply': setting_bool('auto_apply', False), 'notify': setting_bool('notify', True)}, fh)
    except Exception as exc:
        log('could not write heartbeat: %s' % exc, xbmc.LOGWARNING)


def read_heartbeat():
    try:
        with open(paths()['heartbeat'], 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return None


def record_versions(results):
    """Remember each addon's version; log an event when one changed since the last check."""
    p = ensure_dirs()
    current = {}
    for r in results:
        if r['version']:
            current[r['addon']] = r['version']
    try:
        old = {}
        if os.path.isfile(p['versions']):
            try:
                with open(p['versions'], 'r', encoding='utf-8') as fh:
                    old = json.load(fh)
                if not isinstance(old, dict):
                    old = {}
            except Exception:
                old = {}      # empty or half-written file (Kodi closed mid-write): start again instead of failing forever
        changes = []
        for addon, ver in current.items():
            if addon in old and old[addon] != ver:
                changes.append((addon, old[addon], ver))
                event('update detected: %s %s -> %s' % (short_addon(addon), old[addon], ver))
        tmp = p['versions'] + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(current, fh)
        os.replace(tmp, p['versions'])     # atomic swap so a shutdown can never leave an empty file
        return changes
    except Exception as exc:
        log('version tracking failed: %s' % exc, xbmc.LOGWARNING)
        return []


def recent_events(count=8):
    try:
        with open(paths()['events'], 'r', encoding='utf-8') as fh:
            return fh.read().splitlines()[-count:]
    except Exception:
        return []


def service_info_text(results):
    hb = read_heartbeat()
    lines = []
    if hb is None:
        lines.append('Background service: no check recorded yet.')
        lines.append('It starts about a minute after Kodi starts. If this stays empty, check that the add-on is enabled.')
    else:
        ago = (time.time() - hb['time']) / 60.0
        limit = hb['interval'] * 2 + 2
        if ago <= limit:
            lines.append('Background service: [B]RUNNING[/B]')
        else:
            lines.append('Background service: [B]NO RECENT CHECK[/B] (it only runs while Kodi is open, and not during playback)')
        lines.append('Last background check: %s (%.0f min ago)' % (hb['text'], ago))
        lines.append('Result: %s' % hb['state'])
        lines.append('Checks every %d minutes' % hb['interval'])
        lines.append('Re-apply automatically: %s' % ('ON' if hb['auto_apply'] else 'OFF (you re-apply from this menu)'))
        lines.append('Notifications: %s' % ('ON' if hb['notify'] else 'OFF'))
    lines.append('')
    lines.append('[B]Addon versions being watched[/B]')
    seen = {}
    for r in results:
        seen[r['addon']] = (r['version'], r['tested_on'])
    for addon, (ver, tested) in sorted(seen.items()):
        note = '' if (ver is None or ver == tested) else '   (fixes were built on %s)' % tested
        lines.append('  %s: %s%s' % (short_addon(addon), ver or 'not installed', note))
    lines.append('')
    lines.append('[B]Recent events[/B]')
    ev = recent_events()
    lines += ['  ' + e for e in ev] if ev else ['  (none yet)']
    return '\n'.join(lines)


def run_check(manifest):
    """Check every fix, store report.json, write 'needs attention' notes for blocked ones."""
    p = ensure_dirs()
    results = engine.check_all(manifest, p['addons'])
    record_versions(results)
    try:
        with open(p['report'], 'w', encoding='utf-8') as fh:
            json.dump({'checked_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'results': results}, fh, indent=1)
    except Exception as exc:
        log('could not write report: %s' % exc, xbmc.LOGWARNING)
    by_id = {pt['id']: pt for pt in manifest['patches']}
    for r in results:
        if r['status'] in engine.BLOCKED_STATUSES and r['status'] != engine.ST_NOFILE:
            name = '%s_%s_%s.txt' % (r['id'], r['version'], r['status'])
            target = os.path.join(p['attention'], name)
            if not os.path.isfile(target):
                try:
                    with open(target, 'w', encoding='utf-8') as fh:
                        fh.write(engine.attention_snapshot(by_id[r['id']], p['addons']))
                    event('needs attention: %s (%s %s) -> %s' % (r['id'], r['addon'], r['version'], name))
                except Exception as exc:
                    log('could not write attention note: %s' % exc, xbmc.LOGWARNING)
    return results


def signature(results):
    return ';'.join('%s=%s' % (r['id'], r['status']) for r in results if r['status'] != engine.ST_APPLIED)


def split(results):
    fixable = [r for r in results if r['status'] in engine.FIXABLE_STATUSES]
    blocked = [r for r in results if r['status'] in engine.BLOCKED_STATUSES]
    return fixable, blocked


def short_addon(addon_id):
    names = {'plugin.video.umbrella': 'Umbrella', 'plugin.video.otaku': 'Otaku', 'context.otaku': 'Otaku menu',
             'skin.bingie': 'Bingie skin', 'script.bingie.helper': 'Bingie helper'}
    return names.get(addon_id, addon_id)


def addon_list(results):
    seen = []
    for r in results:
        name = short_addon(r['addon'])
        if name not in seen:
            seen.append(name)
    return ', '.join(seen)


def restart_kinds(apply_results, manifest):
    by_id = {pt['id']: pt for pt in manifest['patches']}
    kinds = set()
    for r in apply_results:
        if r.get('changed'):
            kinds.add(by_id[r['id']].get('restart', 'none'))
    kinds.discard('none')
    return kinds


def status_text(results):
    labels = {
        engine.ST_APPLIED: 'OK',
        engine.ST_NEEDS: 'MISSING - can be re-applied',
        engine.ST_PARTIAL: 'PARTLY MISSING - can be re-applied',
        engine.ST_ANCHOR: 'CANNOT PLACE - needs attention',
        engine.ST_AMBIGUOUS: 'CANNOT PLACE (unclear spot) - needs attention',
        engine.ST_NOADDON: 'addon not installed',
        engine.ST_NOFILE: 'file missing',
    }
    out = []
    group = None
    for r in sorted(results, key=lambda x: (x['group'], x['addon'], x['file'])):
        if r['group'] != group:
            group = r['group']
            out.append('')
            out.append('[B]%s[/B]' % group)
        extra = ' (reduced context)' if r.get('fuzzy') else ''
        out.append('  %s - %s %s: [B]%s[/B]%s' % (r['file'].split('/')[-1], short_addon(r['addon']), r['version'] or '-', labels.get(r['status'], r['status']), extra))
        if r['status'] in engine.BLOCKED_STATUSES and r['detail']:
            out.append('      %s' % r['detail'])
    return '\n'.join(out).strip()
