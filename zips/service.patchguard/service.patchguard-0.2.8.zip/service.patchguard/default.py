# -*- coding: utf-8 -*-
"""Patch Guard menu: see which fixes are in place, re-apply missing ones, roll back."""
import os
import traceback

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import engine, guard

HEAD = 'Patch Guard'


def show_status(results):
    xbmcgui.Dialog().textviewer(HEAD + ' - fix status', guard.status_text(results))


def do_check_now(manifest):
    results = guard.run_check(manifest)
    fixable, blocked = guard.split(results)
    counts = engine.summarize(results)
    ok = counts.get(engine.ST_APPLIED, 0)
    lines = ['Checked just now: %d of %d fixes are in place.' % (ok, len(results))]
    if fixable:
        lines.append('')
        lines.append('%d missing and can be re-applied:' % len(fixable))
        lines += ['- %s: %s' % (guard.short_addon(r['addon']), r['group']) for r in fixable]
    if blocked:
        lines.append('')
        lines.append('%d cannot be placed because the addon code changed (needs attention):' % len(blocked))
        lines += ['- %s: %s' % (guard.short_addon(r['addon']), r['group']) for r in blocked]
    if not fixable and not blocked:
        lines.append('')
        lines.append('Nothing to do. Addon versions seen: ' + ', '.join(
            '%s %s' % (guard.short_addon(a), v) for a, v in sorted({(r['addon'], r['version']) for r in results if r['version']})))
    xbmcgui.Dialog().ok(HEAD, '\n'.join(lines))
    return results


def show_service_info(results):
    xbmcgui.Dialog().textviewer(HEAD + ' - background service', guard.service_info_text(results))


def do_apply(manifest, results):
    fixable, _blocked = guard.split(results)
    if not fixable:
        xbmcgui.Dialog().ok(HEAD, 'Nothing to re-apply - every fix that can be placed is already in.')
        return
    names = '\n'.join('- %s: %s%s' % (guard.short_addon(r['addon']), r['group'],
                                      ' (reduced-context match - the surrounding code changed a little)' if r.get('fuzzy') else '')
                      for r in fixable)
    if not xbmcgui.Dialog().yesno(HEAD, 'Re-apply %d missing fix%s?\n\n%s\n\nThe original files are backed up first, '
                                  'so this can be undone.' % (len(fixable), '' if len(fixable) == 1 else 'es', names)):
        return
    p = guard.paths()
    applied, backup_dir = engine.apply_all(manifest, p['addons'], p['backups'], only_ids={r['id'] for r in fixable})
    done = [r for r in applied if r.get('changed')]
    bad = [r for r in applied if not r['ok']]
    if done:
        engine.prune_backups(p['backups'])
    for r in done:
        guard.event('applied by hand: %s' % r['id'])
    for r in bad:
        guard.event('could not apply %s: %s' % (r['id'], r['message']))
    lines = ['Re-applied %d fix%s.' % (len(done), '' if len(done) == 1 else 'es')]
    if bad:
        lines.append('')
        lines.append('%d could not be applied (nothing was changed for these):' % len(bad))
        lines += ['- %s: %s' % (r['id'], r['message']) for r in bad]
    kinds = guard.restart_kinds(applied, manifest)
    xbmcgui.Dialog().ok(HEAD, '\n'.join(lines))
    if 'kodi' in kinds:
        xbmcgui.Dialog().ok(HEAD, 'Restart Kodi to finish: a long-press menu change only loads when Kodi starts.')
    if 'skin' in kinds:
        if xbmcgui.Dialog().yesno(HEAD, 'Skin files were changed. Reload the skin now to use them?'):
            xbmc.executebuiltin('ReloadSkin()')


def do_rollback():
    p = guard.paths()
    backups = list(reversed(engine.list_backups(p['backups'])))
    if not backups:
        xbmcgui.Dialog().ok(HEAD, 'No backups yet - nothing has been re-applied.')
        return
    idx = xbmcgui.Dialog().select(HEAD + ' - roll back to before...', backups)
    if idx < 0:
        return
    chosen = os.path.join(p['backups'], backups[idx])
    files = []
    for _d, _s, names in os.walk(chosen):
        files += names
    if not xbmcgui.Dialog().yesno(HEAD, 'Restore the %d file%s saved in backup %s?\n\nThis undoes the fixes that backup replaced.' % (
            len(files), '' if len(files) == 1 else 's', backups[idx])):
        return
    restored = engine.rollback(chosen, p['addons'])
    guard.event('rolled back %s (%d files)' % (backups[idx], len(restored)))
    xbmcgui.Dialog().ok(HEAD, 'Restored %d file%s. Restart Kodi to be safe.' % (len(restored), '' if len(restored) == 1 else 's'))


def main():
    manifest, problem = guard.load_manifest()
    if manifest is None:
        xbmcgui.Dialog().ok(HEAD, problem)
        return
    while True:
        results = guard.run_check(manifest)
        fixable, blocked = guard.split(results)
        counts = engine.summarize(results)
        ok = counts.get(engine.ST_APPLIED, 0)
        header = '%d of %d fixes in place' % (ok, len(results))
        hb = guard.read_heartbeat()
        if hb is not None:
            header += ' | last background check %s' % hb['text'][11:16]
        if fixable:
            header += ', %d missing' % len(fixable)
        if blocked:
            header += ', %d need attention' % len(blocked)
        options = []
        if fixable:
            options.append(('apply', 'Re-apply %d missing fix%s' % (len(fixable), '' if len(fixable) == 1 else 'es')))
        options.append(('check', 'Check now'))
        options.append(('status', 'Show status of all fixes'))
        options.append(('info', 'Background service info'))
        options.append(('rollback', 'Roll back a re-apply'))
        options.append(('settings', 'Settings'))
        idx = xbmcgui.Dialog().select('%s - %s' % (HEAD, header), [label for _k, label in options])
        if idx < 0:
            return
        key = options[idx][0]
        if key == 'apply':
            do_apply(manifest, results)
        elif key == 'check':
            do_check_now(manifest)
        elif key == 'status':
            show_status(results)
        elif key == 'info':
            show_service_info(results)
        elif key == 'rollback':
            do_rollback()
        elif key == 'settings':
            xbmcaddon.Addon(guard.ADDON_ID).openSettings()


if __name__ == '__main__':
    try:
        main()
    except Exception:
        guard.log('menu failed:\n%s' % traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(HEAD, 'Something went wrong - details are in kodi.log (search for PatchGuard).')
