# -*- coding: utf-8 -*-
"""Patch Guard background service: notices when an addon update removed one of our fixes."""
import traceback

import xbmc
import xbmcgui

from resources.lib import engine, guard


def notify(message, level='info', ms=9000):
    if not guard.setting_bool('notify', True):
        return
    icon = {'info': xbmcgui.NOTIFICATION_INFO, 'warning': xbmcgui.NOTIFICATION_WARNING,
            'error': xbmcgui.NOTIFICATION_ERROR}[level]
    xbmcgui.Dialog().notification('Patch Guard', message, icon, ms)


class Service(object):
    def __init__(self):
        self.last_signature = None   # what we last told the user about
        self.last_applied_note = ''

    def cycle(self):
        """One check, then record a heartbeat so the menu can show the service is alive."""
        state = self._cycle()
        guard.heartbeat(state)
        return state

    def _cycle(self):
        """One check. Returns a short string describing what happened (used by tests)."""
        if xbmc.Player().isPlaying():
            return 'skipped: playback in progress'
        manifest, problem = guard.load_manifest()
        if manifest is None:
            if self.last_signature != 'nomanifest':
                guard.event(problem)
                self.last_signature = 'nomanifest'
            return 'no manifest'
        results = guard.run_check(manifest)
        fixable, blocked = guard.split(results)
        sig = guard.signature(results)

        auto = guard.setting_bool('auto_apply', False)
        # Safety: automatic mode only touches fixes whose surroundings matched exactly. A fix that could only
        # be placed using reduced context is left for the user to confirm from the menu.
        exact = [r for r in fixable if not r.get('fuzzy')]
        if exact and auto:
            by_id = {r['id'] for r in exact}
            applied, backup_dir = engine.apply_all(manifest, guard.paths()['addons'], guard.paths()['backups'],
                                                   only_ids=by_id, min_age=guard.SETTLE_SECONDS)
            done = [r for r in applied if r.get('changed')]
            waiting = [r for r in applied if r.get('waiting')]
            failed = [r for r in applied if not r['ok'] and not r.get('waiting')]
            for r in applied:
                if not (r['ok'] and not r.get('changed')) and not r.get('waiting'):
                    guard.event('%s: %s' % (r['id'], r['message']))
            if done:
                engine.prune_backups(guard.paths()['backups'])
                kinds = guard.restart_kinds(applied, manifest)
                msg = 'Re-applied %d fix%s' % (len(done), '' if len(done) == 1 else 'es')
                if 'kodi' in kinds:
                    msg += '. Restart Kodi to finish.'
                elif 'skin' in kinds:
                    msg += '. Reload the skin (or restart Kodi) to finish.'
                guard.event('auto-applied: %s [backup %s]' % (', '.join(r['id'] for r in done), backup_dir))
                notify(msg)
                self.last_signature = None   # re-evaluate next cycle
                return 'applied %d' % len(done)
            if waiting and not failed:
                return 'waiting for files to settle'
            results = guard.run_check(manifest)
            fixable, blocked = guard.split(results)
            sig = guard.signature(results)

        if sig != self.last_signature:
            self.last_signature = sig
            if fixable:
                held = [r for r in fixable if r.get('fuzzy')] if auto else []
                if held:
                    notify('%d fix%s need%s your OK (%s): the code around %s changed a little. Open Patch Guard to re-apply.' % (
                        len(held), '' if len(held) == 1 else 'es', '' if len(held) != 1 else 's',
                        guard.addon_list(held), 'it' if len(held) == 1 else 'them'), 'warning')
                    guard.event('held for your OK (reduced match): %s' % ', '.join(r['id'] for r in held))
                rest = [r for r in fixable if r not in held]
                if rest:
                    notify('%d fix%s missing after an update (%s). Open Patch Guard to re-apply.' % (
                        len(rest), '' if len(rest) == 1 else 'es', guard.addon_list(rest)), 'warning')
                    guard.event('missing: %s' % ', '.join(r['id'] for r in rest))
            if blocked:
                notify('%d fix%s need%s attention (%s): the addon code changed.' % (
                    len(blocked), '' if len(blocked) == 1 else 'es', '' if len(blocked) != 1 else 's',
                    guard.addon_list(blocked)), 'error')
        return 'checked: %s' % (sig or 'all fixes in place')

    def run(self):
        monitor = xbmc.Monitor()
        guard.event('service started')
        guard.heartbeat('starting (first check in about a minute)')
        if monitor.waitForAbort(60):      # let Kodi settle after start-up
            return
        while not monitor.abortRequested():
            try:
                self.cycle()
            except Exception:
                guard.log('cycle failed:\n%s' % traceback.format_exc(), xbmc.LOGERROR)
            minutes = max(2, guard.setting_int('check_interval', 10))
            if monitor.waitForAbort(minutes * 60):
                break
        guard.event('service stopped')


if __name__ == '__main__':
    Service().run()
