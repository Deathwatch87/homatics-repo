Empty folder: YouTube rows point here until they are switched on.
