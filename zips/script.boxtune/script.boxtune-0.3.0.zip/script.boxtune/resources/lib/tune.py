# -*- coding: utf-8 -*-
"""Box Tuner: settings profile for the Homatics box.

Pure logic only (no Kodi imports) so it can be unit-tested on a PC.
An entry is (kind, addon_or_none, setting_id, wanted_value, why).
  kind 'addon' -> value is a string, written with xbmcaddon.Addon(addon).setSetting
  kind 'kodi'  -> value is a bool / int / str, written through JSON-RPC Settings.SetSettingValue
"""
import json
import os
import shutil

UMB = 'plugin.video.umbrella'
OTK = 'plugin.video.otaku'

# --- things that only make sense on THIS weak box (3.5 GB RAM, Mali-G31, 1080p screen) -----------------------
BOX = [
    ('addon', UMB, 'hosts.quality', '1', 'search 1080p and below only (no 4K on this box)'),
    ('addon', UMB, 'progress.dialog', '2', 'full-screen torrent search window, as on the PC (icon-only hid the search)'),
    ('addon', OTK, 'general.maxResolution', '3', 'Otaku: 1080p maximum'),
    ('kodi', None, 'services.esenabled', False, 'event server off (not needed)'),
    ('kodi', None, 'videoplayer.usedisplayasclock', False, 'do not sync playback to the display clock (slow starts on Android)'),
    ('addon', UMB, 'showunaired', 'false', 'hide unaired episodes'),
    ('addon', UMB, 'mdblist.markwatched', 'false', 'MDBList sync off (saves background work)'),
    ('addon', UMB, 'mdblist.directProgress.scrape', 'false', 'MDBList sync off'),
    ('addon', UMB, 'mdblist.general.notifications', 'false', 'MDBList sync off'),
    ('addon', UMB, 'mdblist.progress.showunaired', 'false', 'MDBList sync off'),
    ('addon', UMB, 'mdblist.service.syncInterval', '30', 'MDBList sync rarely'),
]

# --- carried over from the PC's Umbrella (nothing about accounts, keys, paths or PC hardware) ---------------
UMBRELLA_PC = [
    ('addon', UMB, 'background.service.syncInterval', '10', 'background sync every 10 min'),
    ('addon', UMB, 'bookmarks.auto', 'true', 'automatic bookmarks'),
    ('addon', UMB, 'cache.tmdbcollection', '48', 'cache hours'),
    ('addon', UMB, 'cache.tmdblist', '48', 'cache hours'),
    ('addon', UMB, 'cache.traktprogress', '1', 'cache hours: Trakt progress re-read every hour (0.3.0, was 6)'),
    ('addon', UMB, 'cache.traktunfinished', '1', 'cache hours: "In Progress" re-read from Trakt every hour (0.3.0, was 24; box 1 vs box 2 mismatch)'),
    ('addon', UMB, 'dev.batch.size', '10', 'smaller metadata batches (gentler on the box)'),
    ('addon', UMB, 'scrapers.timeout', '10', 'source search timeout 10 s'),
    ('addon', UMB, 'preemptive.limit.movie', '10', 'pre-emptive source stop: movie limit'),
    ('addon', UMB, 'preemptive.limit.tv', '10', 'pre-emptive source stop: tv limit'),
    ('addon', UMB, 'preemptive.res.movie', '1', 'pre-emptive source stop: movie resolution'),
    ('addon', UMB, 'preemptive.res.tv', '1', 'pre-emptive source stop: tv resolution'),
    ('addon', UMB, 'preemptive.termination.movie', 'true', 'stop searching early once enough good sources'),
    ('addon', UMB, 'preemptive.termination.tv', 'true', 'stop searching early once enough good sources'),
    ('addon', UMB, 'remove.cam.sources', 'true', 'drop CAM sources'),
    ('addon', UMB, 'remove.sd.sources', 'true', 'drop SD sources'),
    ('addon', UMB, 'remove.duplicates.popup', 'true', 'as on the PC'),
    ('addon', UMB, 'rescrape.default', 'true', 'as on the PC'),
    ('addon', UMB, 'sources.nocachepopup', 'true', 'as on the PC'),
    ('addon', UMB, 'sources.retryall', 'true', 'as on the PC'),
    ('addon', UMB, 'source.prioritize.hevc', 'true', 'prefer HEVC sources (the box decodes it in hardware)'),
    ('addon', UMB, 'uncached.seeder.sort', 'true', 'as on the PC'),
    ('addon', UMB, 'stillwatching.count', '5', 'still-watching prompt after 5 episodes'),
    ('addon', UMB, 'tvshows.progress.watched', 'true', 'as on the PC'),
    ('addon', UMB, 'enable.umbrellahidewatched', 'true', 'as on the PC'),
    ('addon', UMB, 'enable.umbrellawidgetcontext', 'true', 'as on the PC'),
    ('addon', UMB, 'multi.unwatched.enabled', 'true', 'as on the PC'),
    ('addon', UMB, 'umbrella.multiSeason', 'true', 'as on the PC'),
    ('addon', UMB, 'umbrella.externalWarning', 'true', 'as on the PC'),
    ('addon', UMB, 'umbrella.colorSecond', 'true', 'as on the PC'),
    ('addon', UMB, 'flatten.tvshows', '0', 'as on the PC'),
    ('addon', UMB, 'sort.shows.order', '0', 'as on the PC'),
    ('addon', UMB, 'searchmovie.indexer', '1', 'as on the PC'),
    ('addon', UMB, 'searchtv.indexer', '1', 'as on the PC'),
    ('addon', UMB, 'trakt.lists.showowner', 'false', 'as on the PC'),
    ('addon', UMB, 'trakt.useLanguage', 'true', 'as on the PC'),
    ('addon', UMB, 'context.useUmbrellaContext', 'false', 'as on the PC (Umbrella context menu off)'),
    ('addon', UMB, 'context.umbrella.addLibtoFavourite', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.addtoLibrary', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.autoPlay', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.clearBookmark', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.libMdblistManager', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.mdblistManager', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.simklManager', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.tmdbListManager', 'false', 'as on the PC'),
    ('addon', UMB, 'context.umbrella.tmdbWatchlist', 'false', 'as on the PC'),
    ('addon', UMB, 'dialogs.button.color', 'FFCC0001', 'same dialog colours as the PC'),
    ('addon', UMB, 'dialogs.button.color.display', '[COLORFFCC0001]FFCC0001[/COLOR]', 'same dialog colours as the PC'),
    ('addon', UMB, 'dialogs.titlebar.color', 'FF7A01CC', 'same dialog colours as the PC'),
    ('addon', UMB, 'dialogs.titlebar.color.display', '[COLORFF7A01CC]FF7A01CC[/COLOR]', 'same dialog colours as the PC'),
    ('addon', UMB, 'highlight.color', 'FFFFFFFF', 'same dialog colours as the PC'),
    ('addon', UMB, 'highlight.color.display', '[COLORFFFFFFFF]FFFFFFFF[/COLOR]', 'same dialog colours as the PC'),
    ('addon', UMB, 'scraper.dialog.color', 'FFCC0001', 'same dialog colours as the PC'),
    ('addon', UMB, 'scraper.dialog.color.display', '[COLORFFCC0001]FFCC0001[/COLOR]', 'same dialog colours as the PC'),
    ('addon', UMB, 'sources.highlight.color', 'FFCC0001', 'same dialog colours as the PC'),
    ('addon', UMB, 'sources.highlight.color.display', '[COLORFFCC0001]FFCC0001[/COLOR]', 'same dialog colours as the PC'),
]

# --- carried over from the PC's Otaku ---------------------------------------------------------------------
OTAKU_PC = [
    ('addon', OTK, 'general.autotrynext', 'true', 'try the next source if one fails'),
    ('addon', OTK, 'general.minResolution', '2', 'ignore sources below 720p'),
    ('addon', OTK, 'general.playstyle.episode', '1', 'as on the PC'),
    ('addon', OTK, 'general.playstyle.movie', '1', 'as on the PC'),
    ('addon', OTK, 'general.smartplay', 'false', 'as on the PC'),
    ('addon', OTK, 'general.terminate.oncloud', 'true', 'stop the search once a cloud source is found'),
    ('addon', OTK, 'general.terminate.onlocal', 'true', 'stop the search once a local source is found'),
    ('addon', OTK, 'show.uncached', 'false', 'hide uncached sources'),
    ('addon', OTK, 'search.adult', 'true', 'as on the PC'),
    ('addon', OTK, 'subtitles.types', '1', 'as on the PC'),
    ('addon', OTK, 'divflavors.showdub', 'true', 'as on the PC'),
    ('addon', OTK, 'watchlist.update.enabled', 'true', 'as on the PC'),
]

# --- Kodi itself (only the non-default ones from the PC that make sense on the box) ---------------------
KODI_PC = [
    ('kodi', None, 'addons.updatemode', 1, 'take add-on updates from any repository, incl. the Homatics one (Kodi: "Any repositories"); updates still install by themselves, Patch Guard re-applies the fixes afterwards'),
    ('kodi', None, 'general.addonnotifications', True, 'as on the PC'),
    ('kodi', None, 'locale.shortdateformat', 'DD/MM/YYYY', 'as on the PC'),
]

# --- 0.2.4: Umbrella watched / In Progress data from Trakt instead of this box's local Kodi data ---------------
# (partner's box 1 had indicators = Local, so Trakt "In Progress" rows stayed empty; her other box uses Trakt)
TRAKT = [
    ('addon', UMB, 'indicators.alt', '1', 'watched + In Progress from Trakt (0 = Local, 1 = Trakt)'),
    ('addon', UMB, 'indicators', 'Trakt', 'label shown in Umbrella settings for the line above'),
]

# --- 0.2.5: Next Episode popup 30 s before the end, and only the short long-press menus ---------------------
PLAYNEXT_MENUS = [
    ('addon', UMB, 'playnext.method', '0', 'Next Episode popup trigger = seconds remaining'),
    ('addon', UMB, 'playnext.time', '30', 'Next Episode popup 30 s before the end (about 20 s to choose)'),
    ('addon', UMB, 'context.umbrella.addtoFavourite', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.artworkCustomize', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.playTrailer', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.playTrailerSelect', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.traktManager', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.customManager', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.floppyManager', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.scrobManager', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.punchplayManager', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.clearProviders', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.rescrape', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.playFromHere', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.sourceSelect', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.findSimilar', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.browseSeries', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
    ('addon', UMB, 'context.umbrella.browseEpisodes', 'false', 'long-press: separate Umbrella entry off (the short menu from Patch Guard replaces it)'),
]

# --- 0.3.0: rows load faster (smaller pages, "Next page" tile kept) + Trakt In Progress always fresh -----------
ROWS_TRAKT = [
    ('addon', OTK, 'interface.watchlist.paging', 'true', 'Otaku watchlist rows in pages (keeps the "Next Page" arrow)'),
    ('addon', OTK, 'interface.perpage.watchlist', '20', 'Otaku watchlist / Next Up: 20 per page instead of 50, then "Next Page"'),
    ('addon', OTK, 'widget.hide.nextpage', 'false', 'Otaku: always show the "Next Page" arrow at the end of a row'),
]

PROFILE = BOX + UMBRELLA_PC + OTAKU_PC + KODI_PC + TRAKT + PLAYNEXT_MENUS + ROWS_TRAKT


def key(entry):
    kind, addon, sid, _value, _why = entry
    return '%s|%s|%s' % (kind, addon or '', sid)


def norm(v):
    if isinstance(v, bool):
        return 'true' if v else 'false'
    return str(v).strip().lower() if str(v).strip().lower() in ('true', 'false') else str(v)


def same(a, b):
    return norm(a) == norm(b)


def load_backup(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_backup(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh, indent=1)
    os.replace(tmp, path)


def plan(get, profile=None):
    """List of (entry, current_value) that differ from the wanted value."""
    out = []
    for e in (profile or PROFILE):
        cur = get(e)
        if cur is None or not same(cur, e[3]):
            out.append((e, cur))
    return out


def apply(get, put, backup_path, profile=None):
    """Write every differing setting. The FIRST original of each setting is kept in the backup file."""
    todo = plan(get, profile)
    backup = load_backup(backup_path)
    for e, cur in todo:
        backup.setdefault(key(e), cur)
    save_backup(backup_path, backup)                 # back up before touching anything
    done, failed = [], []
    for e, cur in todo:
        try:
            put(e, e[3])
            done.append(e)
        except Exception as exc:
            failed.append((e, str(exc)))
    return done, failed, len(profile or PROFILE) - len(todo)


def undo(put, backup_path):
    """Put back the originals recorded by apply()."""
    backup = load_backup(backup_path)
    restored, failed = 0, []
    by_key = dict((key(e), e) for e in PROFILE)
    for k, orig in backup.items():
        e = by_key.get(k)
        if e is None or orig is None:
            continue
        try:
            put(e, orig)
            restored += 1
        except Exception as exc:
            failed.append((k, str(exc)))
    if not failed:
        try:
            os.remove(backup_path)
        except OSError:
            pass
    return restored, failed


# ----------------------------------------------------------------------------- advancedsettings.xml (pure, testable)
# Only these keys may ever be written. algorithmdirtyregions=1: the box's GPU driver has no buffer-age support, so
# without it Kodi redraws the whole screen 60x a second; with it Kodi only redraws when something changed.
ADV_WANTED = {('gui', 'algorithmdirtyregions'): '1'}
ADV_ALLOWED = {('gui', 'algorithmdirtyregions'), ('gui', 'nofliptimeout')}


def adv_apply(path, wanted=None):
    import xml.etree.ElementTree as ET
    wanted = wanted or ADV_WANTED
    for k in wanted:
        if k not in ADV_ALLOWED:
            raise ValueError('refused: %s/%s' % k)
    existed = os.path.isfile(path)
    if existed:
        root = ET.parse(path).getroot()           # refuse to touch a broken file
        if root.tag != 'advancedsettings':
            raise ValueError('unexpected root <%s>' % root.tag)
    else:
        root = ET.Element('advancedsettings')
    changed = False
    for (sect, key), val in wanted.items():
        s = root.find(sect)
        if s is None:
            s = ET.SubElement(root, sect)
        e = s.find(key)
        if e is None:
            e = ET.SubElement(s, key)
        if (e.text or '').strip() != val:
            e.text = val
            changed = True
    if not changed:
        return False, 'already set'
    marker_orig, marker_none = path + '.boxtune-orig', path + '.boxtune-none'
    if not os.path.exists(marker_orig) and not os.path.exists(marker_none):
        if existed:
            shutil.copyfile(path, marker_orig)
        else:
            open(marker_none, 'w').close()
    tmp = path + '.tmp'
    ET.ElementTree(root).write(tmp, encoding='utf-8', xml_declaration=True)
    os.replace(tmp, path)
    return True, 'set (%s)' % ', '.join('%s/%s=%s' % (a, b, v) for (a, b), v in wanted.items())


def adv_undo(path):
    marker_orig, marker_none = path + '.boxtune-orig', path + '.boxtune-none'
    if os.path.exists(marker_orig):
        os.replace(marker_orig, path)
        return 'previous advancedsettings.xml put back'
    if os.path.exists(marker_none):
        if os.path.exists(path):
            os.remove(path)
        os.remove(marker_none)
        return 'advancedsettings.xml removed (there was none before)'
    return 'nothing to undo'
