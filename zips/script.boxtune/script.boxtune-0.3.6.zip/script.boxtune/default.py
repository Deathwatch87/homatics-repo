# -*- coding: utf-8 -*-
import sys

import xbmcgui

from resources.lib import glue, maint


def apply_all(quiet=False):
    text = glue.do_apply(quiet=True)
    note = glue.do_adv(quiet=True)
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', '%s\nSmoother screen setting: %s\n\nRestart Kodi once so everything picks the new values up.' % (text, note))


def undo_all(quiet=False):
    text = glue.do_undo(quiet=True)
    note = glue.do_adv_undo(quiet=True)
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', '%s\nSmoother screen setting: %s\n\nRestart Kodi once.' % (text, note))


def weekly_label():
    return 'Weekly backup: %s' % ('ON (Sundays 4am) - press to switch off' if maint.weekly_backup_on() else 'OFF - press to switch on')


def debug_label():
    try:
        on = maint.debug_on()
    except Exception:
        on = False
    return 'Debug log for tests: %s' % ('ON - press to switch off' if on else 'OFF - press to switch on (off again after 24 h)')


def menu():
    items = [
        ('Show what would change (preview)', glue.do_preview),
        ('Apply tuning (settings + smoother screen)', apply_all),
        ('Undo tuning', undo_all),
        ('Write report to Downloads', glue.do_report),
        ('Copy Kodi logs to Downloads', glue.do_logs),
        ('Export masked settings (for support)', glue.do_export),
        ('Copy support files to Downloads (skin widget lists, add-on code)', glue.do_peek),
        ('Clean picture cache (pictures unused for 30 days)', maint.do_clean_pictures),
        ('Refresh anime art (fetch missing clear logos again)', maint.do_refresh_anime_art),
        ('Anime rows: add Airing Last Season (below Airing This Season)', maint.do_add_airing_last_season),
        ('Back up now', maint.do_backup_now),
        ('Restore a backup', maint.do_restore),
        (weekly_label, maint.do_toggle_weekly_backup),
        (debug_label, maint.do_toggle_debug),
    ]
    while True:
        i = xbmcgui.Dialog().select('Box Tuner 0.3.6', [t() if callable(t) else t for t, _f in items])
        if i < 0:
            return
        if items[i][1]() == maint.CLOSE_MENU:     # Backup add-on now owns the screen
            return


if __name__ == '__main__':
    args = [a.lower() for a in sys.argv[1:]]
    if args[:2] == ['adv', 'undo']:
        glue.do_adv_undo(quiet=True)
    elif args[:1] == ['adv']:
        glue.do_adv(quiet=True)
    elif args:
        modes = {'apply': apply_all, 'undo': undo_all, 'report': glue.do_report, 'export': glue.do_export,
                 'logs': glue.do_logs, 'settings': glue.do_apply, 'peek': glue.do_peek,
                 'cleanpictures': maint.do_clean_pictures, 'refreshart': maint.do_refresh_anime_art, 'airinglast': maint.do_add_airing_last_season, 'backup': maint.do_backup_now}
        if args[0] in modes:
            modes[args[0]](quiet=True)
    else:
        menu()
