# -*- coding: utf-8 -*-
"""Kodi-facing part of Box Tuner: reads/writes settings, writes the report and the masked export."""
import json
import os
import re
import time
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import tune

ADDON_ID = 'script.boxtune'
SECRET = re.compile(r'token|secret|password|apikey|api_key|username|userid|user_id|auth|session|email|device_code|'
                    r'user_slug|imdbuser|cookie|login|\.key|refresh|pin', re.I)


def data_dir():
    p = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    os.makedirs(p, exist_ok=True)
    return p


def out_dir():
    if xbmc.getCondVisibility('System.Platform.Android') and os.path.isdir('/sdcard/Download'):
        return '/sdcard/Download'
    return data_dir()


def usb_dirs():
    """Removable volumes on Android show up as /storage/<ID>; internal storage is 'emulated' / 'self'."""
    found = []
    try:
        for name in sorted(os.listdir('/storage')):
            p = os.path.join('/storage', name)
            if name not in ('emulated', 'self') and os.path.isdir(p):
                found.append(p)
    except Exception:
        pass
    return found


def backup_path():
    return os.path.join(data_dir(), 'backup_v2.json')


def rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        req['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(req)))


def get(entry):
    kind, addon, sid = entry[0], entry[1], entry[2]
    try:
        if kind == 'kodi':
            r = rpc('Settings.GetSettingValue', {'setting': sid})
            return r.get('result', {}).get('value')
        return xbmcaddon.Addon(addon).getSetting(sid)
    except Exception:
        return None


def put(entry, value):
    kind, addon, sid = entry[0], entry[1], entry[2]
    if kind == 'kodi':
        r = rpc('Settings.SetSettingValue', {'setting': sid, 'value': value})
        if 'error' in r or not r.get('result', True):
            raise RuntimeError('Kodi refused %s' % sid)
    else:
        xbmcaddon.Addon(addon).setSetting(sid, str(value) if not isinstance(value, bool) else ('true' if value else 'false'))


def label(e):
    return ('%s: %s' % ((e[1] or 'Kodi').replace('plugin.video.', ''), e[2]))


def do_apply(quiet=False):
    done, failed, already = tune.apply(get, put, backup_path())
    text = 'Changed %d settings, %d were already right.' % (len(done), already)
    if failed:
        text += ' %d could not be set (see report).' % len(failed)
    xbmc.log('[BoxTuner] ' + text, xbmc.LOGINFO)
    for e in done:
        xbmc.log('[BoxTuner] set %s = %s' % (label(e), e[3]), xbmc.LOGINFO)
    for e, why in failed:
        xbmc.log('[BoxTuner] FAILED %s: %s' % (label(e), why), xbmc.LOGWARNING)
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', text + '\n\nRestart Kodi once so every add-on picks the new values up.')
    return text


def do_undo(quiet=False):
    restored, failed = tune.undo(put, backup_path())
    text = 'Restored %d settings to what they were before.' % restored
    if failed:
        text += ' %d could not be restored.' % len(failed)
    xbmc.log('[BoxTuner] ' + text, xbmc.LOGINFO)
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', text)
    return text


def do_preview():
    todo = tune.plan(get)
    if not todo:
        xbmcgui.Dialog().ok('Box Tuner', 'Nothing to change - every setting already matches the profile.')
        return
    lines = ['%s  (now %s -> %s)' % (label(e), cur if cur not in (None, '') else 'unset', e[3]) for e, cur in todo]
    xbmcgui.Dialog().textviewer('%d settings would change' % len(todo), '\n'.join(lines))


def log_tail(max_bytes=400000):
    path = xbmcvfs.translatePath('special://logpath/kodi.log')
    try:
        with open(path, 'rb') as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - max_bytes))
            return fh.read().decode('utf-8', 'replace').splitlines()
    except Exception:
        return []


def do_report(quiet=False):
    lines = ['Box Tuner report  %s' % time.strftime('%Y-%m-%d %H:%M:%S'), '']
    lines.append('Kodi: %s' % xbmc.getInfoLabel('System.BuildVersion'))
    lines.append('Free memory: %s' % xbmc.getInfoLabel('System.Memory(free)'))
    lines.append('Skin: %s' % xbmc.getSkinDir())
    lines.append('')
    todo = dict((tune.key(e), cur) for e, cur in tune.plan(get))
    lines.append('Settings profile (%d entries, %d differ):' % (len(tune.PROFILE), len(todo)))
    for e in tune.PROFILE:
        k = tune.key(e)
        lines.append('  %-6s %-55s now=%-12s wanted=%s' % ('DIFF' if k in todo else 'ok', label(e), todo.get(k, e[3]), e[3]))
    lines.append('')
    try:
        res = rpc('Addons.GetAddons', {'properties': ['version', 'enabled'], 'enabled': True})
        lines.append('Enabled add-ons:')
        for a in sorted(res['result'].get('addons', []), key=lambda x: x['addonid']):
            if a['addonid'].startswith(('plugin.', 'script.', 'skin.', 'service.', 'context.')):
                lines.append('  %s %s' % (a['addonid'], a['version']))
    except Exception as exc:
        lines.append('add-on list failed: %s' % exc)
    lines.append('')
    lines.append('Recent WARNING/ERROR lines from kodi.log:')
    bad = [l for l in log_tail() if 'warning <' in l.lower() or 'error <' in l.lower() or 'exception' in l.lower()]
    lines += ['  ' + l[:260] for l in bad[-60:]] or ['  (none)']
    body = '\n'.join(lines) + '\n'
    name = 'boxtune_report_%s.txt' % time.strftime('%Y%m%d_%H%M')
    path = os.path.join(out_dir(), name)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(body)
    saved = [path]
    for usb in usb_dirs():                      # also try any plugged-in USB stick (Android may refuse; that is fine)
        try:
            target = os.path.join(usb, name)
            with open(target, 'w', encoding='utf-8') as fh:
                fh.write(body)
            saved.append(target)
        except Exception as exc:
            xbmc.log('[BoxTuner] could not write to %s: %s' % (usb, exc), xbmc.LOGINFO)
    if not quiet:
        extra = '' if len(saved) > 1 else '\n\n(Not written to a USB stick - copy it from the box\'s Download folder with a file manager.)'
        xbmcgui.Dialog().ok('Box Tuner', 'Report written to:\n' + '\n'.join(saved) + extra)
    return path


def masked(text):
    out = []
    for line in text.splitlines():
        m = re.match(r'(\s*<setting id="([^"]+)"[^>]*>)(.*?)(</setting>)?\s*$', line)
        if m and SECRET.search(m.group(2)):
            out.append('%s***masked***</setting>' % m.group(1))
        else:
            out.append(line)
    return '\n'.join(out) + '\n'


def do_export(quiet=False):
    path = os.path.join(out_dir(), 'boxexport.zip')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for addon in ('skin.nimbus', 'plugin.video.umbrella', 'plugin.video.otaku'):
            p = xbmcvfs.translatePath('special://profile/addon_data/%s/settings.xml' % addon)
            if os.path.isfile(p):
                with open(p, 'r', encoding='utf-8', errors='replace') as fh:
                    z.writestr('%s_settings_masked.xml' % addon, masked(fh.read()))
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', 'Export written to:\n%s' % path)
    return path


# ----------------------------------------------------------------------------- Kodi logs

def do_logs(quiet=False):
    """Zip kodi.log + kodi.old.log (+ Patch Guard notes) into the Download folder for support."""
    logdir = xbmcvfs.translatePath('special://logpath/')
    path = os.path.join(out_dir(), 'boxlogs_%s.zip' % time.strftime('%Y%m%d_%H%M'))
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for name in ('kodi.log', 'kodi.old.log'):
            p = os.path.join(logdir, name)
            if os.path.isfile(p):
                z.write(p, name)
        pg = xbmcvfs.translatePath('special://profile/addon_data/service.patchguard/')
        if os.path.isdir(pg):
            for name in os.listdir(pg):
                if name.endswith(('.txt', '.log')) or name == 'status.json':
                    z.write(os.path.join(pg, name), 'patchguard/' + name)
    saved = [path]
    for usb in usb_dirs():
        try:
            target = os.path.join(usb, os.path.basename(path))
            with open(path, 'rb') as a, open(target, 'wb') as b:
                b.write(a.read())
            saved.append(target)
        except Exception:
            pass
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', 'Kodi logs copied to:\n' + '\n'.join(saved))
    return path


PEEK_WORDS = ('watch_order', 'watchorder', 'watchlist_to_ep', 'indicators.alt', "'indicators'", 'getTraktIndicatorsInfo')
PEEK_NAMES = ('main.py', 'default.py', 'control.py', 'umbrella.py', 'router.py', 'sources.py', 'player.py',
              'trakt.py', 'playcount.py', 'episodes.py', 'tvshows.py', 'navigator.py', 'cache.py', 'database.py')
PEEK_MAX = 6 * 1024 * 1024


def do_peek(quiet=False):
    """Read-only copy of files needed for support (no settings, no accounts): the skin's generated widget/menu
    XML, context.otaku, Umbrella's settings definition, and Otaku/Umbrella code files that mention watch order
    or watched indicators. Written to boxpeek_<time>.zip in the Download folder."""
    home = xbmcvfs.translatePath('special://home/addons/')
    path = os.path.join(out_dir(), 'boxpeek_%s.zip' % time.strftime('%Y%m%d_%H%M'))
    total = 0
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        def add(full, arc):
            nonlocal total
            try:
                size = os.path.getsize(full)
                if total + size <= PEEK_MAX:
                    z.write(full, arc)
                    total += size
            except Exception:
                pass
        skin_xml = os.path.join(xbmcvfs.translatePath('special://skin/'), 'xml')
        if os.path.isdir(skin_xml):
            for name in sorted(os.listdir(skin_xml)):
                if name.startswith('script-nimbus-'):
                    add(os.path.join(skin_xml, name), 'skin/' + name)
        ctx = os.path.join(home, 'context.otaku')
        for root, dirs, files in os.walk(ctx):
            dirs[:] = [d for d in dirs if d != '__pycache__']
            for f in files:
                if f.endswith(('.py', '.xml')):
                    full = os.path.join(root, f)
                    add(full, 'context.otaku/' + os.path.relpath(full, ctx).replace(os.sep, '/'))
        add(os.path.join(home, 'plugin.video.umbrella', 'resources', 'settings.xml'), 'plugin.video.umbrella/resources/settings.xml')
        for aid in ('plugin.video.otaku', 'plugin.video.umbrella'):
            base = os.path.join(home, aid)
            for root, dirs, files in os.walk(base):
                dirs[:] = [d for d in dirs if d not in ('__pycache__', 'media', 'images')]
                for f in files:
                    if not f.endswith('.py'):
                        continue
                    full = os.path.join(root, f)
                    try:
                        with open(full, 'r', encoding='utf-8', errors='replace') as fh:
                            text = fh.read()
                    except Exception:
                        continue
                    rel = os.path.relpath(full, base).replace(os.sep, '/')
                    if (any(w in text for w in PEEK_WORDS) or f in PEEK_NAMES
                            or (aid == 'plugin.video.umbrella' and '/windows/' in '/' + rel)):
                        add(full, aid + '/' + os.path.relpath(full, base).replace(os.sep, '/'))
    xbmc.log('[BoxTuner] support files copied to %s (%d KB)' % (path, total // 1024), xbmc.LOGINFO)
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', 'Support files copied to:\n%s' % path)
    return path


# ----------------------------------------------------------------------------- advancedsettings.xml

def adv_path():
    return xbmcvfs.translatePath('special://profile/advancedsettings.xml')


def do_adv(quiet=False):
    """Write the box's redraw setting (gui/algorithmdirtyregions=1) into advancedsettings.xml, keeping anything else."""
    p = adv_path()
    try:
        changed, note = tune.adv_apply(p)
    except Exception as exc:
        changed, note = False, 'failed: %s' % exc
    xbmc.log('[BoxTuner] advancedsettings: %s' % note, xbmc.LOGINFO)
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', 'Smoother screen (redraw only when something changes):\n%s\n\nRestart Kodi for it to take effect.' % note)
    return note


def do_adv_undo(quiet=False):
    note = tune.adv_undo(adv_path())
    xbmc.log('[BoxTuner] advancedsettings undo: %s' % note, xbmc.LOGINFO)
    if not quiet:
        xbmcgui.Dialog().ok('Box Tuner', note + '\n\nRestart Kodi for it to take effect.')
    return note
