# -*- coding: utf-8 -*-
"""Box Tuner background service (0.3.0). Runs quietly:
 - about once a month: removes cached pictures not shown for 30 days (only when idle and nothing is playing);
 - switches the debug log off again 24 hours after it was switched on from the Box Tuner menu.
Weekly backups are run by the Kodi Backup add-on's own scheduler (Box Tuner only sets it up)."""
import time

import xbmc

from resources.lib import maint

START_DELAY = 300      # wait 5 minutes after Kodi starts, so start-up and widget loading are never slowed
CHECK_EVERY = 900      # then look every 15 minutes
IDLE_SECONDS = 600     # only clean when nobody has pressed a button for 10 minutes


def quiet_now():
    return not xbmc.Player().isPlaying() and xbmc.getGlobalIdleTime() >= IDLE_SECONDS


def tick(should_stop):
    st = maint.load_state()
    if maint.debug_expired(st):
        try:
            maint.set_debug(False)
            maint.log('debug log switched off after %d hours' % maint.DEBUG_MAX_HOURS)
        except Exception as e:
            maint.log('debug off failed: %s' % e)
    if maint.picture_clean_due(st) and quiet_now():
        try:
            maint.clean_pictures(should_stop=lambda: should_stop() or xbmc.Player().isPlaying())
        except Exception as e:
            maint.log('picture clean failed: %s' % e)


def run():
    mon = xbmc.Monitor()
    maint.log('service started (picture clean-up about monthly when idle, debug log auto-off)')
    st = maint.load_state()
    if 'last_picture_clean' not in st:        # first start after install: count the month from today
        st['last_picture_clean'] = time.time()
        maint.save_state(st)
    if mon.waitForAbort(START_DELAY):
        return
    while not mon.abortRequested():
        tick(mon.abortRequested)
        if mon.waitForAbort(CHECK_EVERY):
            return


if __name__ == '__main__':
    run()
