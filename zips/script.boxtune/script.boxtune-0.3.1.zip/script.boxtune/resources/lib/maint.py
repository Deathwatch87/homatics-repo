# -*- coding: utf-8 -*-
"""Box Tuner 0.3.x maintenance: picture-cache clean-up, backup/restore through the Kodi Backup add-on
(script.xbmcbackup), and a debug-log switch for one-off tests. Used by the menu (default.py) and the
background service (service.py)."""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'script.boxtune'
BACKUP_ID = 'script.xbmcbackup'
STATE = 'maintenance.json'
CLEAN_DAYS = 30            # pictures not shown for this many days are removed from the cache
CLEAN_EVERY_DAYS = 30      # automatic clean-up about once a month
DEBUG_MAX_HOURS = 24       # the debug log switches itself off again after this long
CLOSE_MENU = 'close-menu'  # returned when the Backup add-on takes over the screen (it uses the same list window)


def rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        req['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(req)))


def log(msg):
    xbmc.log('[BoxTuner] ' + msg, xbmc.LOGINFO)


# ----------------------------------------------------------------------------- state (last runs)

def state_path():
    p = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    os.makedirs(p, exist_ok=True)
    return os.path.join(p, STATE)


def load_state():
    try:
        with open(state_path(), encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {}


def save_state(st):
    tmp = state_path() + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(st, fh, indent=1)
    os.replace(tmp, state_path())


# ----------------------------------------------------------------------------- picture cache

def clean_pictures(days=CLEAN_DAYS, limit=4000, progress=None, should_stop=None):
    """Remove cached pictures (thumbnails, posters, fanart) that Kodi has not shown for `days` days.
    Uses Kodi's own Textures API, so it is safe while Kodi runs; anything removed is simply downloaded
    again the next time it is needed. Returns (removed, checked)."""
    cutoff = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - days * 86400))
    res = rpc('Textures.GetTextures', {'filter': {'field': 'lastused', 'operator': 'lessthan', 'value': cutoff}})
    if 'error' in res:
        raise RuntimeError('Kodi refused the picture list: %s' % res['error'].get('message'))
    old = (res.get('result') or {}).get('textures') or []
    old = old[:limit]
    removed = 0
    for n, t in enumerate(old):
        if should_stop and should_stop():
            break
        r = rpc('Textures.RemoveTexture', {'textureid': t['textureid']})
        if r.get('result') == 'OK':
            removed += 1
        if progress and n % 25 == 0:
            progress(int(100.0 * n / max(1, len(old))), removed)
    st = load_state()
    st['last_picture_clean'] = time.time()
    st['last_picture_clean_removed'] = removed
    save_state(st)
    log('picture cache: removed %d of %d pictures unused for %d days' % (removed, len(old), days))
    return removed, len(old)


def do_clean_pictures(quiet=False):
    if quiet:
        return clean_pictures()
    if not xbmcgui.Dialog().yesno('Box Tuner', 'Remove cached pictures that have not been shown for %d days?\n'
                                  'Nothing breaks - they are downloaded again when needed.' % CLEAN_DAYS):
        return None
    dlg = xbmcgui.DialogProgress()
    dlg.create('Box Tuner', 'Cleaning the picture cache...')
    try:
        removed, checked = clean_pictures(progress=lambda pct, n: dlg.update(pct, 'Removed %d pictures...' % n),
                                          should_stop=dlg.iscanceled)
    finally:
        dlg.close()
    xbmcgui.Dialog().ok('Box Tuner', 'Picture cache cleaned: %d old pictures removed.' % removed)
    return removed, checked


def picture_clean_due(st=None):
    st = st if st is not None else load_state()
    return time.time() - float(st.get('last_picture_clean', 0)) > CLEAN_EVERY_DAYS * 86400


# ----------------------------------------------------------------------------- backup (Kodi Backup add-on)

def backup_addon():
    try:
        return xbmcaddon.Addon(BACKUP_ID)
    except Exception:
        return None


def _need_backup_addon():
    xbmcgui.Dialog().ok('Box Tuner', 'The Kodi "Backup" add-on is not installed.\n'
                        'Install it first: Add-ons > Install from repository > Kodi Add-on repository > '
                        'Program add-ons > Backup. Then come back here.')


# what the weekly backup keeps: settings, logins, add-ons, library - not the picture cache (big, rebuilds itself)
BACKUP_SETTINGS = {
    'backup_selection_type': '0',      # Simple
    'backup_addons': 'true',
    'backup_addon_data': 'true',
    'backup_config': 'true',
    'backup_database': 'true',
    'backup_playlists': 'true',
    'backup_profiles': 'true',
    'backup_thumbnails': 'false',
    'compress_backups': 'true',        # one zip file per backup
    'backup_rotation': '4',            # keep the last 4
    'progress_mode': '1',              # background progress bar, never blocks the screen
}
WEEKLY = {'schedule_interval': '2', 'day_of_week': '0', 'schedule_time': '04:00', 'schedule_miss': 'true',
          'enable_scheduler': 'true'}   # every Sunday 04:00; if the box was off, at the next start (switch on last)


def backup_folder_set(addon=None):
    addon = addon or backup_addon()
    if not addon:
        return False
    sel = addon.getSetting('remote_selection')
    if sel == '0':
        return bool(addon.getSetting('remote_path'))
    if sel == '1':
        return bool(addon.getSetting('remote_path_2'))
    return sel in ('2', '3')        # Dropbox / other cloud already set up by the owner: keep it


def choose_backup_folder(addon):
    usb = []
    try:
        usb = [os.path.join('/storage', n) for n in sorted(os.listdir('/storage')) if n not in ('emulated', 'self')]
    except Exception:
        pass
    hint = ('A USB stick is plugged in - pick it (%s) so the backup survives if the box fails.' % usb[0]) if usb else \
        'Tip: a USB stick left in the box is the safest place.'
    xbmcgui.Dialog().ok('Box Tuner', 'Choose where backups go.\n' + hint)
    folder = xbmcgui.Dialog().browse(3, 'Backup folder', 'files', '', False, False, usb[0] if usb else '')
    if not folder:
        return False
    addon.setSetting('remote_selection', '0')
    addon.setSetting('remote_path', folder)
    return True


def prepare_backup_addon(addon, weekly=None):
    for k, v in BACKUP_SETTINGS.items():
        addon.setSetting(k, v)
    if weekly is True:
        for k, v in WEEKLY.items():
            addon.setSetting(k, v)
    elif weekly is False:
        addon.setSetting('enable_scheduler', 'false')


def do_backup_now(quiet=False):
    addon = backup_addon()
    if addon is None:
        return None if quiet else _need_backup_addon()
    if not backup_folder_set(addon) and (quiet or not choose_backup_folder(addon)):
        return None
    prepare_backup_addon(addon)
    if not quiet:
        xbmcgui.Dialog().notification('Box Tuner', 'Backup started - progress shows top right', xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.executebuiltin('RunScript(%s,mode=backup)' % BACKUP_ID)
    log('backup started')
    return CLOSE_MENU


def do_restore():
    addon = backup_addon()
    if addon is None:
        return _need_backup_addon()
    if not backup_folder_set(addon) and not choose_backup_folder(addon):
        return None
    xbmcgui.Dialog().ok('Box Tuner', 'Pick the backup to restore in the next window.\n'
                        'Kodi restarts afterwards. Your current settings are replaced by the backup.')
    xbmc.executebuiltin('RunScript(%s,mode=restore)' % BACKUP_ID)
    return CLOSE_MENU


def weekly_backup_on(addon=None):
    addon = addon or backup_addon()
    return bool(addon and addon.getSetting('enable_scheduler') == 'true')


def do_toggle_weekly_backup():
    addon = backup_addon()
    if addon is None:
        return _need_backup_addon()
    if weekly_backup_on(addon):
        prepare_backup_addon(addon, weekly=False)
        xbmcgui.Dialog().ok('Box Tuner', 'Weekly backup switched OFF.')
        return False
    if not backup_folder_set(addon) and not choose_backup_folder(addon):
        return None
    prepare_backup_addon(addon, weekly=True)
    xbmcgui.Dialog().ok('Box Tuner', 'Weekly backup switched ON: every Sunday at 4am (or at the next start if the box '
                        'was off). Keeps the last 4. Settings, logins, add-ons and library - not the picture cache.')
    return True


# ----------------------------------------------------------------------------- debug log (for one-off tests)

def debug_on():
    r = rpc('Settings.GetSettingValue', {'setting': 'debug.showloginfo'})
    return bool((r.get('result') or {}).get('value'))


def set_debug(on):
    rpc('Settings.SetSettingValue', {'setting': 'debug.showloginfo', 'value': bool(on)})
    st = load_state()
    if on:
        st['debug_on_since'] = time.time()
    else:
        st.pop('debug_on_since', None)
    save_state(st)


def do_toggle_debug():
    if debug_on():
        set_debug(False)
        xbmcgui.Dialog().ok('Box Tuner', 'Debug log switched OFF.')
    else:
        set_debug(True)
        xbmcgui.Dialog().ok('Box Tuner', 'Debug log switched ON (it turns itself off after %d hours).\n'
                            'Make the problem happen, then: Box Tuner > Copy Kodi logs to Downloads.' % DEBUG_MAX_HOURS)


def debug_expired(st=None):
    st = st if st is not None else load_state()
    since = st.get('debug_on_since')
    return bool(since) and time.time() - float(since) > DEBUG_MAX_HOURS * 3600


# ----------------------------------------------------------------------------- anime art (clear logos)

OTAKU_ID = 'plugin.video.otaku'
OTAKU_DB = 'malSync.db'


def otaku_db_path():
    return xbmcvfs.translatePath('special://profile/addon_data/%s/%s' % (OTAKU_ID, OTAKU_DB))


def anime_art_missing(path=None):
    """(total, ids_without_clearlogo) from Otaku's art cache (table shows_meta). Read-only."""
    import pickle
    import sqlite3
    path = path or otaku_db_path()
    if not os.path.isfile(path):
        return 0, []
    con = sqlite3.connect(path, timeout=30)
    try:
        rows = con.execute('SELECT mal_id, art FROM shows_meta').fetchall()
    finally:
        con.close()
    missing = []
    for mal_id, blob in rows:
        try:
            art = pickle.loads(blob) if blob else {}
        except Exception:
            art = {}
        if not (isinstance(art, dict) and art.get('clearlogo')):
            missing.append(mal_id)
    return len(rows), missing


def refresh_anime_art(path=None):
    """Forget the cached art of anime that have no clear logo, so Otaku fetches it again (now from all art sources) the next
    time the anime is shown. A copy of the database is kept next to it. Returns (total, removed)."""
    import shutil
    import sqlite3
    path = path or otaku_db_path()
    total, missing = anime_art_missing(path)
    if not missing:
        return total, 0
    shutil.copy2(path, path + '.bak-boxtune')
    con = sqlite3.connect(path, timeout=30)
    try:
        con.executemany('DELETE FROM shows_meta WHERE mal_id=?', [(m,) for m in missing])
        con.commit()
    finally:
        con.close()
    log('anime art refresh: %d of %d anime had no clear logo, their art will be fetched again' % (len(missing), total))
    return total, len(missing)


def do_refresh_anime_art(quiet=False):
    total, missing = anime_art_missing()
    if quiet:
        return refresh_anime_art()
    if not total:
        xbmcgui.Dialog().ok('Box Tuner', 'No anime art is stored yet - nothing to refresh.')
        return None
    if not missing:
        xbmcgui.Dialog().ok('Box Tuner', 'All %d anime already have a clear logo.' % total)
        return None
    if not xbmcgui.Dialog().yesno('Box Tuner', '%d of %d anime have no clear logo.\nFetch their art again (from Fanart-TV, TMDb and TVDB)?\n'
                                  'It happens the next time each anime is shown, so the first view is a little slower. '
                                  'Some anime have no logo anywhere and will stay without one.' % (len(missing), total)):
        return None
    total, removed = refresh_anime_art()
    xbmcgui.Dialog().ok('Box Tuner', '%d anime will fetch their art again. Open the Anime rows to let it happen.\n'
                        '(Make sure Box Tuner has been applied so all art sources are used.)' % removed)
    return total, removed
